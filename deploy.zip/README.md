﻿---
title: DragonGuide
emoji: ðŸ‰
colorFrom: '#07294D'
colorTo: '#FFC600'
sdk: streamlit
sdk_version: 1.45.1
app_file: main.py
pinned: true
---

# DragonGuide â€” Drexel University Academic AI

Set Space secret: **OPENAI_API_KEY**
